<?php
require __DIR__.'/../app/bootstrap.php'; require_login();
$equipmentTypes=['car'=>'خودرو','motorcycle'=>'موتور سیکلت','led'=>'ال ای دی','gun'=>'سلاح','shocker'=>'شوکر','spray'=>'افشانه','radio'=>'بی‌سیم','hand-caugh'=>'دستبند','mobile'=>'موبایل','computer'=>'رایانه','camera'=>'دوربین','other'=>'سایر'];
$error=''; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 if(!can_manage_personnel()){http_response_code(403);exit('دسترسی غیرمجاز');}
 if(($_POST['action']??'')==='add_equipment'){
  try{
   $pid=(int)($_POST['personnel_id']??0); $items=$_POST['equipment_items']??[];
   if(!$pid || !is_array($items) || !$items) throw new RuntimeException('حداقل یک تجهیز انتخاب کنید.');
   $st=$pdo->prepare('SELECT p.personnel_status,ct.category_key AS unit FROM personnel p JOIN category_types ct ON ct.id=p.category_type_id WHERE p.id=?'); $st->execute([$pid]); $person=$st->fetch();
   if(!$person) throw new RuntimeException('عنصر پیدا نشد.');
   if(person_is_dismissed($person)) throw new RuntimeException('این عنصر برکنار شده است؛ تحویل تجهیزات به او امکان‌پذیر نیست.');
   if(!can_view_unit($person['unit'])) throw new RuntimeException('این عنصر خارج از محدوده دسترسی شماست.');
   $insert=$pdo->prepare('INSERT INTO personnel_equipment(personnel_id,equipment_type,serial_number,delivery_date,return_date,model,color,plate,notes,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
   $added=0;
   foreach($items as $item){
    if(!is_array($item)) continue; $type=(string)($item['type']??'');
    if(!isset($equipmentTypes[$type])) continue;
    $custom=trim((string)($item['custom']??'')); if($type==='other' && $custom==='') throw new RuntimeException('عنوان تجهیز «سایر» را وارد کنید.');
    $serial=trim((string)($item['serial']??'')); $dd=parse_jalali_input($item['delivery']??''); $rd=parse_jalali_input($item['return']??'');
    if($dd && $rd && $rd<$dd) throw new RuntimeException('تاریخ باز تحویل نمی‌تواند قبل از تاریخ تحویل باشد.');
    $model=trim((string)($item['model']??'')); $color=trim((string)($item['color']??'')); $plate=normalize_plate($item['plate']??''); $notes=trim((string)($item['notes']??''));
    if(in_array($type,['car','motorcycle'],true) && $plate!=='' && !valid_iran_plate($plate)) throw new RuntimeException('پلاک را با قالب ۱۲ب۳۴۵-۶۷ وارد کنید.');
    $label=$type==='other'?$custom:$equipmentTypes[$type];
    $insert->execute([$pid,$label,$serial,$dd,$rd,$model,$color,$plate,$notes,user()['id'],user()['id']]); $added++;
   }
   if(!$added) throw new RuntimeException('تجهیز معتبر انتخاب نشده است.');
   $success=$added>1 ? $added.' تجهیز با موفقیت ثبت شد.' : 'تجهیز با موفقیت ثبت شد.';
  }catch(Throwable $e){$error=$e instanceof RuntimeException?$e->getMessage():'عملیات انجام نشد.';}
 }
}
function normalize_plate(?string $v): string {return str_replace([' ','‌'],'',trim((string)$v));}
function valid_iran_plate(string $p): bool {return (bool)preg_match('/^\d{2}[\p{L}]{1}\d{3}-?\d{2}$/u',$p);}
$people=$pdo->query("SELECT p.id,p.full_name,p.national_id,ct.category_key AS unit FROM personnel p JOIN category_types ct ON ct.id=p.category_type_id WHERE ".active_personnel_sql('p')." ORDER BY p.full_name")->fetchAll();
require __DIR__.'/../app/partials/header.php'; ?>
<section class="page-head"><div><h1>تجهیزات</h1></div></section>
<style>.resource-tabs{display:flex;gap:10px;margin:0 0 22px;direction:rtl}.resource-tab{display:inline-flex;align-items:center;justify-content:center;padding:11px 24px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid #d9e2de;background:#fff;color:#244b3b;transition:.2s;box-shadow:0 3px 10px rgba(0,0,0,.05)}.resource-tab:hover{transform:translateY(-2px);box-shadow:0 7px 18px rgba(36,75,59,.12)}.resource-tab.active{background:#244b3b;color:#fff;border-color:#244b3b}</style><div class="resource-tabs" role="tablist" aria-label="مدیریت منابع">
</div>
<?php if($success):?><div class="alert success"><?=e($success)?></div><?php endif;?><?php if($error):?><div class="alert danger"><?=e($error)?></div><?php endif;?>
<?php if(can_manage_personnel()): ?>
<div class="panel"><div class="section-title">ثبت تجهیزات</div><form method="post" class="form-grid" id="equipmentForm"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add_equipment"><label>عنصر<select name="personnel_id" required><option value="">انتخاب عنصر</option><?php foreach($people as $p): if(can_view_unit($p['unit'])): ?><option value="<?=$p['id']?>"><?=e($p['full_name'])?> — <?=e(unit_label($p['unit']))?> — <?=e($p['national_id'])?></option><?php endif; endforeach; ?></select></label><label class="wide">تجهیزات <span class="muted">(چند مورد قابل انتخاب است)</span></label><div class="equipment-picker wide" id="equipmentPicker"><?php foreach($equipmentTypes as $k=>$v): ?><label class="equipment-check"><input type="checkbox" class="equipment-choice" value="<?=e($k)?>" data-label="<?=e($v)?>"><span><?=e($v)?></span></label><?php endforeach; ?></div><div id="equipmentItems" class="wide"></div><div class="actions wide"><button class="btn primary">ثبت تجهیزات انتخاب‌ شده</button></div></form></div>
<?php endif; ?>
<script>const toEn=s=>(s||'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));function maskJalali(el){let v=toEn(el.value).replace(/\D/g,'').slice(0,8);let out=v.slice(0,4);if(v.length>4)out+='/'+v.slice(4,6);if(v.length>6)out+='/'+v.slice(6,8);el.value=out.replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);}document.querySelectorAll('.jalali').forEach(el=>{el.addEventListener('input',()=>maskJalali(el));el.addEventListener('paste',()=>setTimeout(()=>maskJalali(el),0));maskJalali(el);});
const itemBox=document.getElementById('equipmentItems');const choices=[...document.querySelectorAll('.equipment-choice')];const labels={<?php foreach($equipmentTypes as $k=>$v):?><?=json_encode($k)?>:<?=json_encode($v)?>,<?php endforeach;?>};function renderEquipmentItems(){if(!itemBox)return;itemBox.innerHTML='';choices.filter(c=>c.checked).forEach((c,i)=>{const type=c.value,label=labels[type],wrap=document.createElement('div');wrap.className='equipment-item-card';const vehicle=type==='car'||type==='motorcycle',serial=['gun','shocker','spray','radio'].includes(type);wrap.innerHTML=`<div class="equipment-item-head"><strong>${label}</strong><span class="equipment-index">${i+1}</span></div>${type==='other'?`<label>عنوان تجهیز<input name="equipment_items[${i}][custom]" required placeholder="نوع تجهیز را وارد کنید"></label>`:''}<input type="hidden" name="equipment_items[${i}][type]" value="${type}">${serial?`<label>شماره سریال<input name="equipment_items[${i}][serial]" maxlength="120" placeholder="شماره سریال تجهیز"></label>`:''}<div class="form-grid"><label>تاریخ تحویل<input name="equipment_items[${i}][delivery]" class="jalali" inputmode="numeric" maxlength="10" placeholder="۱۴۰۷/۰۷/۰۷"></label><label>تاریخ باز تحویل<input name="equipment_items[${i}][return]" class="jalali" inputmode="numeric" maxlength="10" placeholder="۱۴۰۷/۰۷/۰۷"></label></div>${vehicle?`<div class="form-grid"><label>مدل<input name="equipment_items[${i}][model]"></label><label>رنگ<input name="equipment_items[${i}][color]"></label><label>پلاک<input name="equipment_items[${i}][plate]" inputmode="text" placeholder="۱۲ب۳۴۵-۶۷" maxlength="12"></label></div>`:''}<label>توضیحات<textarea name="equipment_items[${i}][notes]" rows="2"></textarea></label>`;itemBox.appendChild(wrap);wrap.querySelectorAll('.jalali').forEach(el=>{el.addEventListener('input',()=>maskJalali(el));el.addEventListener('paste',()=>setTimeout(()=>maskJalali(el),0));});});}choices.forEach(c=>c.addEventListener('change',renderEquipmentItems));renderEquipmentItems();</script>
<?php require __DIR__.'/../app/partials/footer.php'; ?>


